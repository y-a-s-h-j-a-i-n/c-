#include<iostream>
using namespace std;
class base{
int x;
public:
base(){ cout << "base defalt constrictors";}
};
class derived: public base{
int y;
public:
derived(){ cout << "Derived default constuctor";}
derived(int i){ cout<<"derived parameterized constructor";}
};
int main(){
base b;
derived d1;
derived d2(10);
}
